import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyRentals from './pages/MyRentals'
import RentBike from './pages/RentBike'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<MyRentals />} />
        <Route path="/rent" element={<RentBike />} />
      </Routes>
    </Layout>
  )
}

export default App
