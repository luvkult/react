import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyProjects from './pages/MyProjects'
import Enroll from './pages/Enroll'
import './App.css'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<MyProjects />} />
        <Route path="/enroll" element={<Enroll />} />
      </Routes>
    </Layout>
  )
}

export default App

