import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyRentals from './pages/MyRentals'
import Rent from './pages/Rent'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<MyRentals />} />
        <Route path="/rent" element={<Rent />} />
      </Routes>
    </Layout>
  )
}

export default App
