import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import HistoryPage from './pages/HistoryPage'
import NewConsultation from './pages/NewConsultation'
import './App.css'

function App() {
  return (
    <div className="app">
      <Layout>
        <Routes>
          <Route path="/" element={<HistoryPage />} />
          <Route path="/new" element={<NewConsultation />} />
        </Routes>
      </Layout>
    </div>
  )
}

export default App

