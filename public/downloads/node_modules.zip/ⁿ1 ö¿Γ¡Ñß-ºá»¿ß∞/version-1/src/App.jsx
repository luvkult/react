import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyBookings from './pages/MyBookings'
import BookTraining from './pages/BookTraining'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<MyBookings />} />
        <Route path="/book" element={<BookTraining />} />
      </Routes>
    </Layout>
  )
}

export default App

