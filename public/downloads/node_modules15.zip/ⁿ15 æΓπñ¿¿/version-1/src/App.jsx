import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyBookings from './pages/MyBookings'
import BookStudio from './pages/BookStudio'
import './App.css'

function App() {
  return (
    <div className="app">
      <Layout>
        <Routes>
          <Route path="/" element={<MyBookings />} />
          <Route path="/book" element={<BookStudio />} />
        </Routes>
      </Layout>
    </div>
  )
}

export default App

