import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyCourses from './pages/MyCourses'
import EnrollCourse from './pages/EnrollCourse'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<MyCourses />} />
        <Route path="/enroll" element={<EnrollCourse />} />
      </Routes>
    </Layout>
  )
}

export default App

