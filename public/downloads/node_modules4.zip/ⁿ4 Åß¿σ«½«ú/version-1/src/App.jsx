import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import SessionsHistory from './pages/SessionsHistory'
import BookSession from './pages/BookSession'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<SessionsHistory />} />
        <Route path="/book" element={<BookSession />} />
      </Routes>
    </Layout>
  )
}

export default App

