import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyTours from './pages/MyTours'
import BookTour from './pages/BookTour'
import './App.css'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<MyTours />} />
        <Route path="/book" element={<BookTour />} />
      </Routes>
    </Layout>
  )
}

export default App

