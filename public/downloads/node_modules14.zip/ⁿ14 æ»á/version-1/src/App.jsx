import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyVisits from './pages/MyVisits'
import BookProcedure from './pages/BookProcedure'
import './App.css'

function App() {
  return (
    <div className="app">
      <Layout>
        <Routes>
          <Route path="/" element={<MyVisits />} />
          <Route path="/book" element={<BookProcedure />} />
        </Routes>
      </Layout>
    </div>
  )
}

export default App

