import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import MyCourses from './pages/MyCourses'
import Enroll from './pages/Enroll'
import './App.css'

function App() {
  return (
    <div className="app">
      <Layout>
        <Routes>
          <Route path="/" element={<MyCourses />} />
          <Route path="/enroll" element={<Enroll />} />
        </Routes>
      </Layout>
    </div>
  )
}

export default App

